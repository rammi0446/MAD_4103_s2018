
document.getElementById("findMyRide").addEventListener("click",book);
function book(){

var from = document.getElementById("from").value;
var to = document.getElementById("to").value;
var ride = document.getElementsByName('ride');
if(from=="a" && to=="b" || from=="c" && to=="d")
{

for (var i = 0, length = ride.length; i < length; i++)
    {
    if (ride[i].checked)
    {
  // do whatever you want with the checked radio
    alert(ride[i].value);
    if(ride[i].value=="pool")
    {
    console.log("pool");
    if(from == "a" && to=="b"){
        var dist = (0.50*22.9);
        console.log("from:"+from);
        console.log("To:"+to);

        document.getElementById("fromNext").innerHTML = from;
        document.getElementById("toNext").innerHTML = to;
         document.getElementById("distanceCharge").innerHTML = dist;

        var total=(2.50)+(dist)+(1.75);
        document.getElementById("total").innerHTML = "$"+total;
    }

    else
    {
            var dist = (0.50*1.2);
            console.log("from:"+from);
            console.log("To:"+to);
             document.getElementById("distanceCharge").innerHTML = dist;
            document.getElementById("fromNext").innerHTML = from;
            document.getElementById("toNext").innerHTML = to;


         var total=(2.50)+(dist)+(1.75);
            document.getElementById("total").innerHTML = "$"+total;
    }

    }
    else
    {
    console.log("direct");

    if(from == "a" && to=="b"){
        var dist = (0.81*22.9);
        console.log("from:"+from);
        console.log("To:"+to);

        document.getElementById("fromNext").innerHTML = from;
        document.getElementById("toNext").innerHTML = to;
         document.getElementById("distanceCharge").innerHTML = dist;

        var total=(2.50)+(dist)+(1.75);
        document.getElementById("total").innerHTML = "$"+total;
    }

    else
    {
            var dist = (0.81*1.2);
            console.log("from:"+from);
            console.log("To:"+to);
             document.getElementById("distanceCharge").innerHTML = dist;
            document.getElementById("fromNext").innerHTML = from;
            document.getElementById("toNext").innerHTML = to;


         var total=(2.50)+(dist)+(1.75);
            document.getElementById("total").innerHTML = "$"+total;
    }
    }
  // only one radio can be logically checked, don't check the rest
  break;
    }
    }

    
    





  //   console.log("right");
  //   for (var i = 0, length = ride.length; i < length; i++)
  //   {
  //   if (ride[i].checked)
  //   {
  // // do whatever you want with the checked radio
  //   alert(ride[i].value);
  //   if(ride[i].value=="pool")
  //   {
  //   console.log("pool");

  //   }
  //   else
  //   {
  //   console.log("direct");
  //   }
  // // only one radio can be logically checked, don't check the rest
  // break;
  //   }
  //   }
    

}



/////location not in ride
else
{
    console.log("wrong");
}















//end of function
}
