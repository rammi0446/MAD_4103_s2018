document.getElementById("save").addEventListener("click",saveData);
document.getElementById("show").addEventListener("click",showData);
document.addEventListener("deviceReady",connectToDatabase);

var db = null;
//open a connection with database

function connectToDatabase() {
  console.log("device is ready - connecting to database");
  // 2. open the database. The code is depends on your platform!
  if (window.cordova.platformId === 'browser') {
    console.log("browser detected...");
    // For browsers, use this syntax:
    //  (nameOfDb, version number, description, db size)
    // By default, set version to 1.0, and size to 2MB
    db = window.openDatabase("cestar", "1.0", "Database for Cestar College app", 2*1024*1024);
  }
  else {
    alert("mobile device detected");
    console.log("mobile device detected!");
    var databaseDetails = {"name":"cestar.db", "location":"default"}
    db = window.sqlitePlugin.openDatabase(databaseDetails);
    console.log("done opening db");
  }

  if (!db) {
    alert("databse not opened!");
    return false;
  }




//create aa table

db.transaction(
        function(tx){
            // Execute the SQL via a usually anonymous function 
            // tx.executeSql( SQL string, arrary of arguments, success callback function, failure callback function)
            // To keep it simple I've added to functions below called onSuccessExecuteSql() and onFailureExecuteSql()
            // to be used in the callbacks
            tx.executeSql(
                "CREATE TABLE IF NOT EXISTS employees (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, dept TEXT)",
                [],
                onSuccessExecuteSql,
                onError
            )
        },
        onError,
        onReadyTransaction
    )
    }
//write sql query



//

function saveData(){
console.log("save button clicked");
alert("save button clicked");
var name= document.getElementById("name").value;
var dept= document.getElementById("dept").value;
console.log(name,dept);


db.transaction(
        function(tx){
            tx.executeSql( "INSERT INTO employees(name, dept) VALUES(?,?)",
            [name,dept],
            onSuccessExecuteSql,
            onError )
        },
        onError,
        onReadyTransaction
    )

}

//show ======================
function showData(){
document.getElementById("resultsSection").innerHTML = "";
console.log("show button clicked");
alert("show button clicked");

db.transaction(
        function(tx){
            tx.executeSql( "SELECT * FROM employees",
            [],
            displayResults,
            onError )
        },
        onError,
        onReadyTransaction
    )

}



//common database function

function onReadyTransaction( ){
  console.log( 'Transaction completed' )
}
function onSuccessExecuteSql( tx, results ){
  console.log( 'Execute SQL completed' )
}
function onError( err ){
  console.log( err )
}
function displayResults( tx, results ){
        
        if(results.rows.length == 0) {
            alert("No records found");
            return false;
        }
        
        var row = "";
        for(var i=0; i<results.rows.length; i++) {
      document.getElementById("resultsSection").innerHTML +=
          "<p> Name: "
        +   results.rows.item(i).name
        + "<br>"
        + "Dept: "
        +   results.rows.item(i).dept
        + "</p>";
     
        }
       
    }


