document.addEventListener("deviceready", onDeviceReady, false);
function onDeviceReady() {
console.log(navigator.contacts);
document.getElementById("contacts").innerHTML = navigator.contacts;
}
