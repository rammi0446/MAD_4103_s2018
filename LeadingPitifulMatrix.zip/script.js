console.log("javascript loaded");
var extendedprice;
var quantity;
var unitprice;
function minusPants()
{
  console.log("minus function works");
  unitprice = 20;
  var minus=  document.getElementById('pants').innerHTML; 
  if(minus!=0)
  {
 minus--;
 document.getElementById("pants").innerHTML = minus;
 quantity= document.getElementById("pants").innerHTML;
 console.log(quantity);

 extendedprice = (unitprice*quantity);
 console.log(extendedprice);


  }
}

function plusPants()
{
   unitprice = 20;
  console.log("plus function works");
 var plus=  document.getElementById('pants').innerHTML; 
 plus++;
 document.getElementById("pants").innerHTML = plus;
 quantity= document.getElementById("pants").innerHTML;
 console.log(quantity);
 extendedprice = (20*quantity);
 console.log(extendedprice);

}